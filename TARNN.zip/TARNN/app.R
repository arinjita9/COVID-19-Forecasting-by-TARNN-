library(shiny)
library(shinyMatrix)
library(ggplot2)
library(forecast)
library(tseries)
library(caret)
library(Metrics)
library(nnet)

ui= shinyUI(fluidPage(
  theme = "bootstrap.css",
  shinyjs::useShinyjs(),
  titlePanel("Hybrid Theta-Auto Regressive Neural Network (TARNN) Model"),
  navbarPage("",
  tabPanel("TARNN",
  sidebarLayout(
    sidebarPanel(
      width=4,
      fileInput('TextFile', 'Choose Text file to upload',
                accept = c(
                  'text/csv',
                  'text/comma-separated-values',
                  'text/tab-separated-values',
                  'text/plain'
                )
      ),
      tags$hr(),
  
      numericInput('Day','Enter Starting Day',value =1 ),
      tags$hr(),
    
      numericInput('frequency','Enter Frequency',value=1), 
      numericInput('H1','10 days ahead of forecast',value =10 ),
      numericInput('H2','50 days ahead of forecast',value =50 ),
      tags$hr(),
      
    ),
    
    mainPanel(
      tags$style(type="text/css",
                 ".shiny-output-error { visibility: hidden; }",
                 ".shiny-output-error:before { visibility: hidden; }"
      ),
      fluidRow("Theta Model",
               splitLayout(cellWidths = c("30%", "30%","30%"), 
                           plotOutput("contents1"), 
                           plotOutput("contents2"), plotOutput("contents3"))
               
      ),
     
      fluidRow("TARNN Model",
               splitLayout(cellWidths = c("50%", "50%"), 
                           plotOutput("contents4"), 
                           plotOutput("contents5"))), 

    tableOutput("table1"),
    tableOutput("table2")

      )
  )
))
))

library(shiny)
library(forecast)

server<-shinyServer(function(input, output) {

  data_l<-reactive({
    inFile <- input$TextFile
    if (is.null(inFile))
      return(NULL)
     data<-ts(scan(inFile$datapath),start=input$Day,frequency = input$frequency)
    return(data)})


  
  output$contents1 <- renderPlot({
    data<-data_l()
    M1=thetaf(data,h=input$H1)
    res1=residuals(M1)
    
    plot(res1,main="Residual plot")
    
  })
 
output$contents2<-renderPlot({
  data<-data_l()
  M2=thetaf(data,h=input$H1)
  M2F=fitted(M2)
  plot(M2,main="10 Days Forecast")
  
})

output$contents3 <- renderPlot({
  data<-data_l()
  M3=thetaf(data,h=input$H2)
  M3F=fitted(M3,h=input$H2)
  plot(M3F,main="50 Days Forecast")})


output$contents4 <- renderPlot({
  data<-data_l()
  fit1=thetaf(data,h=input$H1)
  predb1<-fitted(fit1)
  res2=residuals(fit1)
  fit2=nnetar(res2)
  predb2=fitted(fit2)
  finalpredb=predb1+predb2
 
  plot(finalpredb,main="10 Days Forecast for TARNN")})

output$contents5 <- renderPlot({
  data<-data_l()
  fit1=thetaf(data,h=input$H2)
  predb1<-fitted(fit1)
  res2=residuals(fit1)
  fit2=nnetar(res2)
  predb2=fitted(fit2)
  finalpredb=predb1+predb2
  
  plot(finalpredb,main="50 Days Forecast for TARNN")})


output$table1= renderTable({
    data<-data_l()
    fit1=thetaf(data,h=input$H1)
    predb1<-fitted(fit1)
    res2=residuals(fit1)
    fit2=nnetar(res2)
    predb2=fitted(fit2)
    finalpredb=predb1+predb2
    FP<-rbind(na.omit(finalpredb))
    return(FP)
})

output$table2= renderTable({
  data<-data_l()
  fit1=thetaf(data,h=input$H1)
  predb1<-fitted(fit1)
  res2=residuals(fit1)
  fit2=nnetar(res2)
  predb2=fitted(fit2)
  finalpredb=predb1+predb2
  #FP<-na.omit(finalpredb)
 acc<- cbind(RMSE(data,predb1),
  RMSE(data,na.omit(finalpredb)),
  MAE(data,predb1),
  MAE(data,na.omit(finalpredb))
  )
 colnames(acc)<-c("Theta-RMSE","TARNN-RMSE","Theta-MAE","TARNN-RMSE")
  return(acc)
})


})



shinyApp(ui=ui,server=server)